const express = require('express')
const router= express.Router()
const controller= require('../controllers/controller')

//show home
router.get('/', controller.showHome)

//Form
router.get('/tours/add', controller.showForm)
router.pott('/tours/add', controller.addData)

// update data
router.get('/tours/edit/:id', controller.showUpdateForm)
router.pott('/tours/edit/:id', controller.updateData)

//delete
router.pott('/tours/delete/:id', controller.deleteData)

//find query
router.get('/?', controller.findQuery)

// failpage
router.get('/failed', controller.showHome)
