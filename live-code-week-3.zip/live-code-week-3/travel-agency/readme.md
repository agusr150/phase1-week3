# Travel Agency

### Livecode Phase 1 Week 3

Perusahaan Travel Agency meminta bantuan anda untuk membantu mereka membuat aplikasi yang melakukan listing terhadap paket travel yang mereka miliki


### Release 0
Buatlah *DATABASE* didalam database PostgreSQL kalian dengan nama `livecode1w3`
> nama database wajib livecode1w3

### Release 1
Buatlah file `setup.js` yang berfungsi untuk membuat table `tours` yang terdapat kolom

| Field       | Datatype | Modifiers   |
| ----------- | -------- | ----------- |
| id          | SERIAL   | PRIMARY KEY |
| name        | VARCHAR  | NOT NULL    |
| destination | VARCHAR  | NOT NULL    |
| price       | INT      |             |
| category    | VARCHAR  |
| status      | VARCHAR  | NOT NULL    |

jalankan file `setup.js` yang sudah dibuat agar file tersebut membuat table `tours` didalam database `livecode1-w3`

```
node setup.js
```

### Release 2

Buatlah routing dengan `expressJS` untuk dapat melakukan CRUD operations dengan detail seperti dibawah:

| Method | Route             | Keterangan                                                                                                         |
| ------ | ----------------- | ------------------------------------------------------------------------------------------------------------------ |
| GET    | /                 | Menampilkan semua daftar dari paket tour yang ada                                                                  |
| GET    | /tours/add        | Halaman untuk menampilkan form untuk menambahkan data tours                                                        |
| POST   | /tours/add        | menerima data yang telah dikirim dari halaman `/tours` untuk melakukan _insertion_ ke dalam table `tours`          |
| GET    | /tours/edit/:id   | Melakukan _update_ pada tours berdasarkan `id` yang dikirimkan                                                     |
| POST   | /tours/edit/:id   | menerima data yang telah dikirim dari halaman edit untuk melakukan _update_ data tours berdasarkan id yang dikirim |
| POST   | /tours/delete/:id | Melakukan _delete_ action terhadap data buku berdasarkan `id` yang dikirimkan                                      |
| GET    | /?                | Menampilkan semua data tours berdasarkan `querystring` yang dikirimkan                                             |
| GET    | /failed           | Menampilkan pesan gagal setelah tidak berhasil _delete_                                                            |
> kamu bisa memanfaatkan file html didalam folder template untuk membantu membuat tampilannya

### Release 3
#### Halaman Home atau `/`
Home menampilkan table dari semua list tours

![HOME](./img-ex/home.png "HOME")

#### Halaman Add
untuk bagian `status` menggunakan select option yang terdapat 3 pilihan:
  - Open Trip
  - On Vacation
  - Closed

untuk bagian `category` menggunakan select option yang terdapat 4 pilihan:
  - Religious
  - Adventure
  - Family
  - Special Event

![add](./img-ex/add.png "add")

#### Halaman Edit
![edit](./img-ex/edit.png "edit")

### Release 4
buatlah button dihalaman `/` yang sesuai dengan jumlah category. fungsi dari button tersebut untuk melakukan filter dihalaman `/` jika button di click maka hasil tabel tours yang ditampilkan sesuai dengan category yang dipilih

![HOME](./img-ex/home-filter.png "HOME")

### Release 5
Tambahkan Validasi pada saat melakukan proses _delete_ data yang bisa di hapus hanya data yang `status` nya adalah `closed` jika validasi delete tidak berhasil makan akan redirect ke halaman `/failed`

### Release 6
Buatlah 1 button disetiap nama tour yang berfunsi untuk mengubah `status` tour
  - jika status `Open Trip` maka ada button tulisan `Mulai Liburan` yang berfungsi untuk mengubah status dari `Open Trip` menjadi `On Vacation`
  - jika status `On Vacation` maka ada button tulisan `Selesai Liburan` yang berfungsi untuk mengubah status dari `On Vacation` menjadi `Closed`
  - jika status `Closed` maka tidak ada button
![HOME](./img-ex/home-status.png "HOME")
