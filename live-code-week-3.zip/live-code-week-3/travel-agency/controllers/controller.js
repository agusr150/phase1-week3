const pool = require('../connection/connection')
const destination = require('../models/destination')

class Controllers {
    static showHome(req,res){
        destination.getData((err,data)=>{
            if (err){
                console.log(err)
            } else {
                res.render('index',{tour:data})
            }
        })
    }

    static showForm(req,res){
        res.render('forms')
    }

    static addData(req,res){
        destination.addDataForms(req.query,(err,data)=>{
            if (err){
                res.send(err)
            }else{
                res.redirect('index',{})
            }
        })
    }

    static showUpdateForm(req,res){
        destination.updateForms()
    }

    static updateData(req,res){

    }

    static deleteData(req,res){

    }

    static findQuery(req,res){

    }

    static showHome(req,res){

    }
}