const pool = require('../connection/connection')

class Destination {

    static getData(cb){
        pool.query(`SELECT * FROM tour`,(err,data)=>{
            if (err) {
                cb (err,null)
            } else {
                cb(null,data.rows)
            }
        })
    }

    static updateForms(){
        
    }


}