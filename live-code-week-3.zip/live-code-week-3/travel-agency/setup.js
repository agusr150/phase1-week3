const pool = require('./connection/connection')

pool.query(`CREATE TABLE IF NOT EXIST tour (
id SERIAL PRIMARY KEY,
name VARCHAR NOT NULL,
destination VARCHAR NOT NULL,
price INT,
category VARCHAR,
status VARCHAR NOT NULL
);`,(err,data)=>{
    if (err){
        console.log(err)
    } else {
        console.log('ciaat ciaaatttt')
    }
})