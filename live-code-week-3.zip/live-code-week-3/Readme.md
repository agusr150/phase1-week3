# live-code-week-3

RULES:

- Kerjakan secara individu. Semua bentuk diskusi tidak diperbolehkan dan menyebabkan skor live code ini 0.
- Clone repo ‘live-code-week-3’ pada organization majestic-fox-2019. Buatlah branch dengan nama kalian
- Kerjakan pada file javascript yang telah disediakan
- Membuka referensi eksternal seperti Google, StackOverflow, dan MDN diperbolehkan.
- Pada text editor hanya ada folder ‘live-code-week-3‘
- Dilarang membuka _repository_ di organisasi tugas, baik pada organisasi batch sendiri ataupun batch lain, baik branch sendiri maupun branch orang lain (setelah melakukan clone, close tab github pada web browser kalian). Lakukan git add, git commit, git push dan pull request pada saat diperintahkan
- Tuliskan nama lengkap kalian saat melakukan pull request
- Jika tidak membuat pull request maka nilai akan dinilai berdasarkan hasil pull request

### Jangan lupa .gitignore!